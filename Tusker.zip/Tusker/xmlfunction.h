#ifndef XMLFUNCTION_H
#define XMLFUNCTION_H


class XmlFunction
{
public:
    XmlFunction();

    void createFile();
    void childElement();
    void writeToFile();

};



#endif // XMLFUNCTION_H
